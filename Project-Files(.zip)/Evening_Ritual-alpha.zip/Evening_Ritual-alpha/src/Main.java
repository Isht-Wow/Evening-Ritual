import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Variables v = new Variables();
        Logic l = new Logic(v);
        UI UI = new UI(v);
        UI.mainMenu();
    }
}
