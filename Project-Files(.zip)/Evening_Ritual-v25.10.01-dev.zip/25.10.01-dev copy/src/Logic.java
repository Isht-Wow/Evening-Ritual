import java.util.Random;

public class Logic {
    Random random = new Random();
}
