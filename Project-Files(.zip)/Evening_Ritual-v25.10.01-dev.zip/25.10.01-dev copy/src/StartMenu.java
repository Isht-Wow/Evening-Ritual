public class StartMenu {
    public static void display() {
    }
}
