public class EveningRitual {
    public static void main(String[] args) {
        ConfigManager.loadConfig();
        SettingsMenu.display();
    }
}