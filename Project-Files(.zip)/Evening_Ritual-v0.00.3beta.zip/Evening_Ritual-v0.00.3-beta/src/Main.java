public class Main {
    public static void main(String[] args) {
        Variables v = new Variables();
        UI UI = new UI(v);
        UI.mainMenu();
    }
}
