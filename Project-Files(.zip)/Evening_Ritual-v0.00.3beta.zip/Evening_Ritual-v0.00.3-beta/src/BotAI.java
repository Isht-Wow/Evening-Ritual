public class BotAI extends Main  {
    Variables v;
   public BotAI(Variables variables){
        this.v = variables;
    }

}
